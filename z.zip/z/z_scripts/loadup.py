def loadup():
    print('Z')